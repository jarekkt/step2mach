//=====================================================================
//
//	Plugin::MG - Plugin's ManagedGlobal (MG) class
//
//	place static members here to hold our global handles and managed
//	data which need to persist. they will need to be 'copied' to working
//	variables in the functions that use them so that the 'static' will
//	not interfere with operations.
//
//	see xyzdemo for examples of usage
//
//=====================================================================

#ifdef _MANAGED
#pragma managed

using namespace mach_plugin;

namespace mach_plugin
{
	public ref struct	XYZDemoConfig
	{
		bool	enableDlg;	// enable (show) the dialog
		bool	enableX;	// enable X DRO
		bool	enableY;	// enable Y DRO
		bool	enableZ;	// enable Z DRO
	};

	public ref class MG
	{
	public:
		//--- sample of a global modeless dialog -----
		//static	MonitorDialog^ monitorDialog;
		//--------------------------------------------
		static	XYZDemoConfig^	xyzDemoConfig;
		static	XYZDemoDialog^	xyzDemoDialog;
	};
}
#endif
