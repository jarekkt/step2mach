#pragma once

#include "stdafx.h"

class MyConsoleClass
{
	HWND    hhwnd;
	HANDLE  hhandle;
	BOOL  ConsoleValid;

public:
	MyConsoleClass();
	virtual ~MyConsoleClass();

	void ConsolePrint(int x, int y,const char * msg);

};