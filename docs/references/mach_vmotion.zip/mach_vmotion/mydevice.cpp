#include "stdafx.h"
#include "MachDevice.h"
#include "mydevice.h"




MyDeviceClass::MyDeviceClass()
{
	// Just to put data on simple console window
	console  = new MyConsoleClass;
	hardware = new MyHardwareClass(console,MOTION_TIME_SLICE);

	memset(&stats,0,sizeof(stats));
}

MyDeviceClass::~MyDeviceClass()
{
	delete hardware;
	delete console;
}


void  MyDeviceClass::InitControl()
{
	// Comment from "art"
	//
	//		Take note you have to set MachView->m_PrinterOn = false in the myInitControl function to indicate an external device plugin
	//		as well as have set MainPlanner->ExternalType = EX_VMS; for variable ms timing, 
	//		and set the MainPlanner->ExTime == .001 for 1ms timed waypoints..
	//		Then, you have to set the axis maximums , then motor tuning can work..
	//		This woudl set the max to 75K steps/second for example.. The user can then tune the motors with the motor tuning..
	//			for( int x = 0; x < 7; x++ )MainPlanner->ExternalPulseRates* = 75000;
	//
	//		Now if you command a move, the positions will be in the RingBuffer at
	//		MainPlanner->Movements[Engine->TrajIndex].sx;   sy,sz..ect..
	//		I believe the ncPod plugin shows incremental motion from the .ex, .ey, .ez var's, and the sx, sy, sz vars show absolute position..


	// We do not use printer port - we are its replacement
	MachView->m_PrinterOn = false;

	// This seems to be movement buffer length ( in movements)
	MainPlanner->ExBufferHi		= 350;

	// This seems to be single movement length ( in seconds)
	//
	// Comment from "smurph" :
	//		1ms may be putting the trajectory planner through too much.  Or dumping that much granular data to your device may be the bottle neck. 
	//		I've run some of my plugins at 32ms.  But I had the capability of matching that time slice in the hardware.  
	//		The reduced resolution is only noticed at very slow speeds. 
	//		You will never notice anything with a time slice of 16ms or lower.  So if 1ms is not a requirement, try some higher values.  
	//		The Galil plugin uses 4ms time slices and it flies


	MainPlanner->ExTime			= MOTION_TIME_SLICE;


	//  Comment from "smurph" :
	//		Movement type:
	// 			EX_VMS: This is basically what would have been sent to the parallel port.  It is incremental position over time.
	//			EX_COMMAND:  This might be what you would like to use.  Where you send endpoint data to the device.  It uses the GMoves and GMoves1 structures to provide data.  But it eliminates Mach directing things that I described above.
	//			EX_DDA:  That was basically only used to output cubic profile data to the G100 GRex.  It's probably not useful for any other device.
	//
	//  I choose EX_VMS so Mach trajectory planner will make all calculations for us

	MainPlanner->ExternalType	= EX_VMS; 


	//  Setup external pulse rate
	//  Set the max speeds of MAch3 for this device
	//
	//	Comment from "jarek" : I guess this has to match your hardware capablities

	for( int x = 0; x < 7; x++ )
	{
		MainPlanner->ExternalPulseRates[x] = 1000000;
	}



}


//	From GALIL plugin example:
//
//		Called when mach fully set up so all data can be used but initialization  outcomes not affected
//		In the case of a MotionControl plugin, this rouine is only called to tell us to 
//		take over. We HAVE been selected and are now commanded to do whatever it takes 
//		to OWN the IO and movement of this run.
//		If you wish for example, to zero all IO at this point, your free to do so..


void  MyDeviceClass::PostInitControl()
{
	console->ConsolePrint(0,0,"MACH Virtual plugin activated");
}





// 
//	Main update loop at 10hz.
//	Called only when plugin enabled
//
void  MyDeviceClass::Update()
{
	char	buffer[128];
	static  int divider;

	sprintf_s(buffer,"Mach Coordinates :X(%12f) Y(%12f) Z(%12f) A(%12f)",
						GetDRO(800),GetDRO(801),GetDRO(802),GetDRO(803));
	console->ConsolePrint(0,1,buffer);

	if(divider++%10 == 0)
	{
		DumpConfig();		
	}

	SendHoldingMovement();
	GetInputs();
	SetOutputs();
	HandleSequences();

}



//
//	Here we process Mach trajector and send movements to the device
//
// 
void  MyDeviceClass::SendHoldingMovement()
{
 	  
	 //If these ring buffer pointers are not equal, we have movement waiting..
	 if( Engine->TrajHead != Engine->TrajIndex) 
	 {  
	 
		 //if Mavg is not set properly for the coming movement, set it now in a dwell message of 0 dwell
		  while ( Engine->TrajHead != Engine->TrajIndex )
		  {
			stats.TrajectoryItems++;

			Engine->DisplayLine = Engine->Trajectories[ Engine->TrajIndex ].ID;

			//We will now loop though the moves that are holding.. 
			GMoves move =  MainPlanner->Movements[Engine->TrajIndex];

			//you must deal with this "move" , then increment the ring buffer and so forth till no more moves exist.
			hardware->AddMove(&move);

			Engine->TrajIndex++;  //increment ring
			Engine->TrajIndex &= 0xfff; //rotate the ring if necessary..
		  }
	 }
	

	 if( (Engine->TrajHead == Engine->TrajIndex) &&  MainPlanner->BufferEnding )
	 {
		// Comment from "jarek" Looks like no more data in the trajectory. 
		// Tell it to the device
		hardware->FinalizeMoves();
	 }


}

//
//	Get inputs from the device and set them in Mach3s variables..
//
//
void MyDeviceClass::GetInputs(void)
{
   hardware->UpdatePosition();	
}



//
//	Query Mach for outpus required and send them to the device
//
//
void MyDeviceClass::SetOutputs(void)
{
  

}



//
//	Handle any sequenctial logic from int to int you may use..
//
//
void MyDeviceClass::HandleSequences(void)
{
 

}



//
//	  Turn on a jog in this routine..
//
//

void MyDeviceClass::JogOn( short axis, short direction, double SpeedNorm)
{
	stats.JogOnCall++;  
}



//
//	  Turn off a jog in this routine..
//
//
void  MyDeviceClass::JogOff(short axis)
{
  int check = 0;

  stats.JogOffCall++;


  Engine->Axis[axis].Dec = true;
  Engine->Axis[axis].Jogging = false;
  
  for( int x = 0; x<6; x++ )
  {
    if( !Engine->Axis[x].Jogging ) check ++;
  }

  if( check >= 6) //no axis jogging, lets do a sync..
  {
	  Engine->Jogging = false;
	  MainPlanner->Jogging = false;
	  Engine->Sync = true;
  }
}

//
//	  
//
//
 void MyDeviceClass::Dwell(double time)
 {
	 stats.DwellCall++;
 }


//
//	  
//
//
 void  MyDeviceClass::Home(short axis)
 {
	stats.HomeCall++;
 }


//
//	  
//
//
 void  MyDeviceClass::Probe(void)
 {
	stats.ProbeCall++;
 }

//
//	  
//
//
void MyDeviceClass::Purge(short flags)
{
	stats.PurgeCall++;
}


//
//	  
//
//
void MyDeviceClass::Reset(void)
{
	stats.ResetCall++;
}



//
//	  Dumps most important internal variables used during movement
//       
//
void  MyDeviceClass::DumpConfig(void)
{
	int		ii;
	int		col = 20;
	char	buffer[256];
	char    axis[] = "XYZABC";

	// Dump axix info

	for(ii = 0; ii < 4;ii++)
	{
		sprintf_s(buffer,"%c Vel:%8.4f Acc:%8.4f Steps:%12.4f Epr:%8.4f Dir:%d Slave:%d SlaveA:%d SlimHi:%8d SlimLo:%8d",
					axis[ii],
					MainPlanner->Velocities[ii],
					MainPlanner->Acceleration[ii],
					MainPlanner->StepsPerAxis[ii],
					MainPlanner->ExternalPulseRates[ii],
					(int)Engine->Directions[ii],
					(int)Engine->Axis[ii].Slave,
					Engine->Axis[ii].SlaveAxis,
					Engine->SoftLimitsHi[ii],
					Engine->SoftLimitsLo[ii]
		);

		console->ConsolePrint(0,col++,buffer);
	}
	
	col++;

	sprintf_s(buffer,"Calls-> Traj:%5lu JogOn:%3u JogOff:%3u Dwell:%3u  Home:%3u Probe:%3u Purge:%3u Reset:%3u",
					stats.TrajectoryItems,
					stats.JogOnCall,
					stats.JogOffCall,
					stats.DwellCall,
					stats.HomeCall,
					stats.ProbeCall,
					stats.PurgeCall,
					stats.ResetCall					
	);

	console->ConsolePrint(0,col++,buffer);


}