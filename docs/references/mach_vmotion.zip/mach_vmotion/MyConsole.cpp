#include "stdafx.h"
#include "myconsole.h"
#include "stdio.h"


MyConsoleClass::MyConsoleClass()
{

	ConsoleValid = AllocConsole();

	if(ConsoleValid)
	{
		SetConsoleTitle("VMOTION plugin - MACH virtual motion device");

		hhwnd   = GetConsoleWindow();
		hhandle = GetStdHandle(STD_OUTPUT_HANDLE);
				
	}

}

MyConsoleClass::~MyConsoleClass()
{


}

void MyConsoleClass::ConsolePrint(int x, int y,const char * msg)
{
	DWORD NumberOfCharsWritten;
	COORD dwCursorPosition;
         
	if(ConsoleValid)
	{
		 dwCursorPosition.X = x;
		 dwCursorPosition.Y = y;
		 SetConsoleCursorPosition(hhandle,dwCursorPosition);
		 WriteConsole(hhandle,msg,strlen(msg),&NumberOfCharsWritten,NULL);
	}
}
		
