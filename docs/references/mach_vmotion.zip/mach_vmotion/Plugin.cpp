//=====================================================================
//
//	Plugin.cpp - the optional custom part of the plugin
//
//	this source file can be filled with the actual custom code that
//	makes the plugin work. it is the choice of the developer to enable
//	which functions will be used from the available MachDevice calls.
//
//	if this is a mixed mode dll each function can be declared as either
//	an unmanaged or managed function.
//
//	please see the documentation in Plugin.h for the #define statements
//	that control each functions compilation.
//
//	if this is a mixed mode dll and you need to keep global managed
//	reference please see the MG class in ManagedGlobal.h
//
//	please read the notes and comments in MachDevice.cpp for general
//	information and disclaimers.
//
//=====================================================================

#include "stdafx.h"
#include "Plugin.h"
#include "MachDevice.h"
#include "ConfigDialog.h"
#include "PlugInControlDialog.h"
#include "XYZDemoDialog.h"
#include "XMLNetProfile.h"
#include "ManagedGlobal.h"
#include "MyDevice.h"

#include <stdlib.h>

//---------------------------------------------------------------------
//	the default namespace for managed functions and classes
//---------------------------------------------------------------------

using namespace mach_plugin;

//---------------------------------------------------------------------
//	data area
//---------------------------------------------------------------------

int					menuStart;				// the starting menu id
MyDeviceClass	 *  MyDevice;

//---------------------------------------------------------------------
//
//	piInitControl() - Plugin extension of InitControl()
//
//		XML file can NOT be accessed since SetProName hasn't
//		been called yet
//
//		called EVEN if plugin is disabled
//
//---------------------------------------------------------------------

#ifdef PI_INITCONTROL
#ifdef _MANAGED
#pragma PI_MIX_INITCONTROL
#endif
bool piInitControl()
{
	menuStart = GetMenuRange(MENU_COUNT);

	MyDevice  = new MyDeviceClass;

	MyDevice->InitControl();

	return true;
}
#endif

//---------------------------------------------------------------------
//
//	piSetProName() - Plugin extension of SetProName()
//
//		XML file CAN be accessed
//
//		called EVEN if plugin is disabled
//
//---------------------------------------------------------------------

#ifdef PI_SETPRONAME
#ifdef _MANAGED
#pragma PI_MIX_SETPRONAME
#endif
char* piSetProName(LPCSTR name)
{
	XYZDemoConfig^	xyzDemoConfig = gcnew XYZDemoConfig;
	XMLNetProfile^	profile = gcnew XMLNetProfile(gcnew String(ProfileName), "mach_vmotion_plugin", true);

	profile->Load();

	xyzDemoConfig->enableDlg = profile->ReadBool("Dlg"   , false);
	xyzDemoConfig->enableX   = profile->ReadBool("Axis/X", true);
	xyzDemoConfig->enableY   = profile->ReadBool("Axis/Y", true);
	xyzDemoConfig->enableZ   = profile->ReadBool("Axis/Z", true);

	MG::xyzDemoConfig = xyzDemoConfig;

	return "mach_vmotion-jaroslaw_karwik-v1.0.0.0";
}
#endif

//---------------------------------------------------------------------
//
//	piPostInitControl() - Plugin extension of PostInitControl()
//
//		XML file can NOT be accessed
//
//		called ONLY if plugin is enabled
//
//---------------------------------------------------------------------

#ifdef PI_POSTINITCONTROL
#ifdef _MANAGED
#pragma PI_MIX_POSTINITCONTROL
#endif
void piPostInitControl()
{
	HMENU			hMachMenu = GetMenu(MachView->MachFrame->m_hWnd);
	HMENU			hPluginMenu = 0;
	int				machMenuCnt = GetMenuItemCount(hMachMenu);
	MENUITEMINFO	mii;
	LPTSTR			txt;

	for (int i = 0; i < machMenuCnt; i++)
	{
		mii.cbSize     = sizeof(MENUITEMINFO);
		mii.fMask      = MIIM_FTYPE | MIIM_ID | MIIM_SUBMENU | MIIM_STRING;
		mii.dwTypeData = NULL;

		if (GetMenuItemInfo(hMachMenu, i, true, &mii))
		{
			txt = (LPTSTR) malloc(++mii.cch);
			mii.dwTypeData = txt;

			if (GetMenuItemInfo(hMachMenu, i, true, &mii))
			{
				if (strcmp(txt, "PlugIn Control") == 0)
				{
					hPluginMenu = mii.hSubMenu;
					i = machMenuCnt;
				}
			}

			free(txt);
		}

		if (hPluginMenu)
		{
			InsertMenu(hPluginMenu, -1, MF_BYPOSITION, menuStart  , "mach_vmotion");
		}
	}

	XYZDemoDialog^	xyzDemoDialog = gcnew XYZDemoDialog();

	xyzDemoDialog->labelX->Visible = MG::xyzDemoConfig->enableX;
	xyzDemoDialog->labelY->Visible = MG::xyzDemoConfig->enableY;
	xyzDemoDialog->labelZ->Visible = MG::xyzDemoConfig->enableZ;

	xyzDemoDialog->textBoxX->Visible = MG::xyzDemoConfig->enableX;
	xyzDemoDialog->textBoxY->Visible = MG::xyzDemoConfig->enableY;
	xyzDemoDialog->textBoxZ->Visible = MG::xyzDemoConfig->enableZ;

	xyzDemoDialog->Visible = MG::xyzDemoConfig->enableDlg;

	MG::xyzDemoDialog = xyzDemoDialog;


	MyDevice->PostInitControl();

}
#endif

//---------------------------------------------------------------------
//
//	piConfig() - Plugin extension of Config()
//
//		called if user presses CONFIG in Config|Config Plugins
//		even if plugin is disabled
//
//		XML file CAN be accessed
//
//---------------------------------------------------------------------

#ifdef PI_CONFIG
#ifdef _MANAGED
#pragma PI_MIX_CONFIG
#endif
void piConfig()
{
	ConfigDialog^	configDialog = gcnew ConfigDialog();

	configDialog->ShowDialog();
}
#endif

//---------------------------------------------------------------------
//
//	piStopPlug() - Plugin extension of StopPlug()
//
//---------------------------------------------------------------------

#ifdef PI_STOPPLUG
#ifdef _MANAGED
#pragma PI_MIX_STOPPLUG
#endif
void piStopPlug()
{
	XYZDemoConfig^	xyzDemoConfig = MG::xyzDemoConfig;
	XMLNetProfile^	profile = gcnew XMLNetProfile(gcnew String(ProfileName), "mach_vmotion_plugin", true);

	if (profile->Load())
	{
		if (MG::xyzDemoDialog) xyzDemoConfig->enableDlg = MG::xyzDemoDialog->Visible;

		profile->WriteBool("Dlg"   ,xyzDemoConfig->enableDlg);
		profile->WriteBool("Axis/X",xyzDemoConfig->enableX);
		profile->WriteBool("Axis/Y",xyzDemoConfig->enableY);
		profile->WriteBool("Axis/Z",xyzDemoConfig->enableZ);

		profile->Save();
	}
}
#endif

//---------------------------------------------------------------------
//
//	piUpdate() - Plugin extension of Update()
//
//		XML file can NOT be accessed
//
//		called ONLY if plugin is enabled
//
//		WARNING - when you enable a plugin it immediately is added
//		to the update loop. if you haven't initialized some items
//		because PostInitControl() hasn't been called you can get
//		some problems!!!
//
//---------------------------------------------------------------------

#ifdef PI_UPDATE
#ifdef _MANAGED
#pragma PI_MIX_UPDATE
#endif
void piUpdate()
{
	if (MG::xyzDemoDialog)
	{
		XYZDemoDialog^	xyzDemoDialog = MG::xyzDemoDialog;

		xyzDemoDialog->textBoxX->Text = GetDRO(800).ToString("F4");
		xyzDemoDialog->textBoxY->Text = GetDRO(801).ToString("F4");
		xyzDemoDialog->textBoxZ->Text = GetDRO(802).ToString("F4");
	}


	MyDevice->Update();
}
#endif

//---------------------------------------------------------------------
//
//	piNotify() - Plugin extension of Notify()
//
//		among other notices this is where we are notified when the
//		user clicks on our 'PlugIn Control' menu item.
//
//		XML file CAN be accessed on a menu item notify
//
//---------------------------------------------------------------------

#ifdef PI_NOTIFY
#ifdef _MANAGED
#pragma PI_MIX_NOTIFY
#endif
void piNotify(int id)
{
	if (id == menuStart)
	{
		PlugInControlDialog^	pluginControlDialog = gcnew PlugInControlDialog();
		XYZDemoConfig^			xyzDemoConfig = MG::xyzDemoConfig;

		xyzDemoConfig->enableDlg = MG::xyzDemoDialog->Visible;

		pluginControlDialog->checkBoxDlg->Checked = xyzDemoConfig->enableDlg;
		pluginControlDialog->checkBoxX->Checked   = xyzDemoConfig->enableX;
		pluginControlDialog->checkBoxY->Checked   = xyzDemoConfig->enableY;
		pluginControlDialog->checkBoxZ->Checked   = xyzDemoConfig->enableZ;

		if (pluginControlDialog->ShowDialog() == DialogResult::OK)
		{
			xyzDemoConfig->enableDlg = pluginControlDialog->checkBoxDlg->Checked;
			xyzDemoConfig->enableX   = pluginControlDialog->checkBoxX->Checked;
			xyzDemoConfig->enableY   = pluginControlDialog->checkBoxY->Checked;
			xyzDemoConfig->enableZ   = pluginControlDialog->checkBoxZ->Checked;

			XYZDemoDialog^	xyzDemoDialog = MG::xyzDemoDialog;

			xyzDemoDialog->labelX->Visible = xyzDemoConfig->enableX;
			xyzDemoDialog->labelY->Visible = xyzDemoConfig->enableY;
			xyzDemoDialog->labelZ->Visible = xyzDemoConfig->enableZ;

			xyzDemoDialog->textBoxX->Visible = xyzDemoConfig->enableX;
			xyzDemoDialog->textBoxY->Visible = xyzDemoConfig->enableY;
			xyzDemoDialog->textBoxZ->Visible = xyzDemoConfig->enableZ;

			xyzDemoDialog->Visible = xyzDemoConfig->enableDlg;
		}
	}
}
#endif

//---------------------------------------------------------------------
//
//	piDoDwell() - Plugin extension of DoDwell()
//
//---------------------------------------------------------------------

#ifdef PI_DODWELL
#ifdef _MANAGED
#pragma PI_MIX_DODWELL
#endif
void piDoDwell(double time)
{
	MyDevice->Dwell(time);
}
#endif

//---------------------------------------------------------------------
//
//	piReset() - Plugin extension of Reset()
//
//---------------------------------------------------------------------

#ifdef PI_RESET
#ifdef _MANAGED
#pragma PI_MIX_RESET
#endif
void piReset()
{
	MyDevice->Reset();
}
#endif

//---------------------------------------------------------------------
//
//	piJogOn() - Plugin extension of JogOn()
//
//---------------------------------------------------------------------

#ifdef PI_JOGON
#ifdef _MANAGED
#pragma PI_MIX_JOGON
#endif
void piJogOn(short axis, short dir, double speed)
{
	MyDevice->JogOn(axis, dir, speed);
}
#endif

//---------------------------------------------------------------------
//
//	piJogOff() - Plugin extension of JogOff()
//
//---------------------------------------------------------------------

#ifdef PI_JOGOFF
#ifdef _MANAGED
#pragma PI_MIX_JOGOFF
#endif
void piJogOff(short axis)
{
	MyDevice->JogOff(axis);
}
#endif

//---------------------------------------------------------------------
//
//	piPurge() - Plugin extension of Purge()
//
//---------------------------------------------------------------------

#ifdef PI_PURGE
#ifdef _MANAGED
#pragma PI_MIX_PURGE
#endif
void piPurge(short flags)
{
	MyDevice->Purge(flags);
}
#endif

//---------------------------------------------------------------------
//
//	piProbe() - Plugin extension of Probe()
//
//---------------------------------------------------------------------

#ifdef PI_PROBE
#ifdef _MANAGED
#pragma PI_MIX_PROBE
#endif
void piProbe()
{
	MyDevice->Probe();
}
#endif 

//---------------------------------------------------------------------
//
//	piHome() - Plugin extension of Home()
//
//---------------------------------------------------------------------

#ifdef PI_HOME
#ifdef _MANAGED
#pragma PI_MIX_HOME
#endif
void piHome(short axis)
{
	MyDevice->Home(axis);
}
#endif
