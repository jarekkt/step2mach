#include "stdafx.h"
#include "MyHardware.h"
#include "math.h"



MyHardwareClass::MyHardwareClass(MyConsoleClass * console,double move_tick)
{
	this->console	= console;
	this->move_tick	= move_tick;

	memset(posMach,0,sizeof(posMach));
	memset(posAccumulated,0,sizeof(posAccumulated));
	memset(steps,0,sizeof(steps));


}

MyHardwareClass::~MyHardwareClass()
{

}

void   MyHardwareClass::AddMove(GMoves * move)
{

	posMach[0] = move->sx;
	posMach[1] = move->sy;
	posMach[2] = move->sz;
	posMach[3] = move->sa;

	posAccumulated[0] += move->ex;
	posAccumulated[1] += move->ey;
	posAccumulated[2] += move->ez;
	posAccumulated[3] += move->ea;

	steps[0] += (int)move->ex;
	steps[1] += (int)move->ey;
	steps[2] += (int)move->ez;
	steps[3] += (int)move->ea;
}

void  MyHardwareClass::FinalizeMoves(void)
{
	// No more data ? Tell Mach that we have finished
	//
	// Comment from "art" : ExternalStill -  plugin telling mach3 it is idle, all movement is complete.
	MainPlanner->ExternalStill = true;
}



void   MyHardwareClass::UpdatePosition(void)
{
	int	 ii;
	char buffer[256];

	for(ii = 0; ii < 4;ii++)
	{
		Engine->Axis[ii].Index = steps[ii];
	}


	sprintf_s(buffer,"Hardware acum    :X(%12f) Y(%12f) Z(%12f) A(%12f)",
			         posAccumulated[0],posAccumulated[1],posAccumulated[2],posAccumulated[3]
	);
	console->ConsolePrint(0,2,buffer);

	sprintf_s(buffer,"Hardware steps   :X(%12d) Y(%12d) Z(%12d) A(%12d)",
			         steps[0],steps[1],steps[2],steps[3]
	);
	console->ConsolePrint(0,3,buffer);

	sprintf_s(buffer,"Mach curent      :X(%12f) Y(%12f) Z(%12f) A(%12f)",
			         posMach[0],posMach[1],posMach[2],posMach[3]
	);
	console->ConsolePrint(0,4,buffer);


}
