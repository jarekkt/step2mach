#pragma once

#include "stdafx.h"
#include "myConsole.h"
#include "MachDevice.h"



class MyHardwareClass
{
private:
	int      steps[4];
	double   posAccumulated[4];
	double   posMach[4];
	double	 move_tick;

	MyConsoleClass * console;

public:
	MyHardwareClass(MyConsoleClass * console,double move_tick);
	virtual ~MyHardwareClass();

	void   AddMove(GMoves * move);
	void   FinalizeMoves(void);
	void   UpdatePosition(void);

};