#pragma once

#include "stdafx.h"
#include "myConsole.h"
#include "myHardware.h"

#define  MOTION_TIME_SLICE		0.004 /* in seconds */


typedef struct
{
	unsigned int	JogOnCall;
	unsigned int	JogOffCall;
	unsigned int	DwellCall;
	unsigned int	HomeCall;
	unsigned int	ProbeCall;
	unsigned int	PurgeCall;
	unsigned int	ResetCall;
	unsigned long	TrajectoryItems;

}MyDeviceStatsType;



class MyDeviceClass
{
private:

	MyConsoleClass		* console;
	MyHardwareClass		* hardware;
	MyDeviceStatsType	  stats;	

	void  SendHoldingMovement(void);
	void  GetInputs(void);
	void  SetOutputs(void);
	void  HandleSequences(void);

	void  DumpConfig(void);

public:
	MyDeviceClass();
	virtual ~MyDeviceClass();


	void  InitControl(void);
	void  PostInitControl(void);
	void  JogOn( short axis, short direction, double SpeedNorm);
	void  JogOff(short axis);
	void  Dwell(double time);
	void  Home(short axis);
	void  Probe(void);
	void  Purge(short flags);
	void  Reset(void);
    void  Update(void);	

};
