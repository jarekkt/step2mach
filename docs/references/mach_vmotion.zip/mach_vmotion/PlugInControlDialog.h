#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace mach_plugin {

	/// <summary>
	/// Summary for PlugInControlDialog
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class PlugInControlDialog : public System::Windows::Forms::Form
	{
	public:
		PlugInControlDialog(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~PlugInControlDialog()
		{
			if (components)
			{
				delete components;
			}
		}

	private: System::Windows::Forms::Button^  OKButton;
	private: System::Windows::Forms::Button^  CancelButton;
	public: System::Windows::Forms::CheckBox^  checkBoxDlg;
	public: System::Windows::Forms::CheckBox^  checkBoxX;
	public: System::Windows::Forms::CheckBox^  checkBoxY;
	public: System::Windows::Forms::CheckBox^  checkBoxZ;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->OKButton = (gcnew System::Windows::Forms::Button());
			this->CancelButton = (gcnew System::Windows::Forms::Button());
			this->checkBoxDlg = (gcnew System::Windows::Forms::CheckBox());
			this->checkBoxX = (gcnew System::Windows::Forms::CheckBox());
			this->checkBoxY = (gcnew System::Windows::Forms::CheckBox());
			this->checkBoxZ = (gcnew System::Windows::Forms::CheckBox());
			this->SuspendLayout();
			// 
			// OKButton
			// 
			this->OKButton->Location = System::Drawing::Point(56, 195);
			this->OKButton->Name = L"OKButton";
			this->OKButton->Size = System::Drawing::Size(75, 23);
			this->OKButton->TabIndex = 0;
			this->OKButton->Text = L"OK";
			this->OKButton->UseVisualStyleBackColor = true;
			this->OKButton->Click += gcnew System::EventHandler(this, &PlugInControlDialog::OKButton_Click);
			// 
			// CancelButton
			// 
			this->CancelButton->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->CancelButton->Location = System::Drawing::Point(154, 195);
			this->CancelButton->Name = L"CancelButton";
			this->CancelButton->Size = System::Drawing::Size(75, 23);
			this->CancelButton->TabIndex = 1;
			this->CancelButton->Text = L"Cancel";
			this->CancelButton->UseVisualStyleBackColor = true;
			// 
			// checkBoxDlg
			// 
			this->checkBoxDlg->AutoSize = true;
			this->checkBoxDlg->Location = System::Drawing::Point(56, 37);
			this->checkBoxDlg->Name = L"checkBoxDlg";
			this->checkBoxDlg->Size = System::Drawing::Size(108, 17);
			this->checkBoxDlg->TabIndex = 2;
			this->checkBoxDlg->Text = L"Display Modeless";
			this->checkBoxDlg->UseVisualStyleBackColor = true;
			// 
			// checkBoxX
			// 
			this->checkBoxX->AutoSize = true;
			this->checkBoxX->Location = System::Drawing::Point(56, 79);
			this->checkBoxX->Name = L"checkBoxX";
			this->checkBoxX->Size = System::Drawing::Size(93, 17);
			this->checkBoxX->TabIndex = 3;
			this->checkBoxX->Text = L"X DRO Visible";
			this->checkBoxX->UseVisualStyleBackColor = true;
			// 
			// checkBoxY
			// 
			this->checkBoxY->AutoSize = true;
			this->checkBoxY->Location = System::Drawing::Point(56, 105);
			this->checkBoxY->Name = L"checkBoxY";
			this->checkBoxY->Size = System::Drawing::Size(93, 17);
			this->checkBoxY->TabIndex = 4;
			this->checkBoxY->Text = L"Y DRO Visible";
			this->checkBoxY->UseVisualStyleBackColor = true;
			// 
			// checkBoxZ
			// 
			this->checkBoxZ->AutoSize = true;
			this->checkBoxZ->Location = System::Drawing::Point(56, 131);
			this->checkBoxZ->Name = L"checkBoxZ";
			this->checkBoxZ->Size = System::Drawing::Size(93, 17);
			this->checkBoxZ->TabIndex = 5;
			this->checkBoxZ->Text = L"Z DRO Visible";
			this->checkBoxZ->UseVisualStyleBackColor = true;
			// 
			// PlugInControlDialog
			// 
			this->AcceptButton = this->OKButton;
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 264);
			this->Controls->Add(this->checkBoxZ);
			this->Controls->Add(this->checkBoxY);
			this->Controls->Add(this->checkBoxX);
			this->Controls->Add(this->checkBoxDlg);
			this->Controls->Add(this->CancelButton);
			this->Controls->Add(this->OKButton);
			this->Name = L"PlugInControlDialog";
			this->Text = L"PlugInControlDialog";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
private: System::Void OKButton_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->DialogResult = System::Windows::Forms::DialogResult::OK;
			 this->Close();
		 }
	};
}
